import java.util.Scanner;
import java.util.TreeMap;

import com.sun.corba.se.impl.encoding.OSFCodeSetRegistry.Entry;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;

public class Function {
	static Scanner in = new Scanner(System.in);
	Map<String,Integer> hMap = new HashMap<String, Integer>();
	
	public void wordfrequency(TreeMap<String, Integer> wordFrequent) {
		Set<Map.Entry<String, Integer>> set=wordFrequent.entrySet();
		System.out.println("��������Ҫͳ�Ƶĵ��ʣ�");
		String words = in.nextLine();
		String[] word= words.split(" ");
		boolean flag=true;
		while(flag)
		{
			for(int i=0; i<word.length; i++) 
	        {
	        	for(Map.Entry<String,Integer> e : set) 
	        	{ 
	        		if(word[i].equals(e.getKey()))
	        		{  
	        			System.out.println(e.getKey() + "������" + e.getValue()+"��");
	        			double area=e.getValue()/500; 
	        			for(int j=0; j<=area; j++)
	        			{
	        				System.out.print("��");
	        			}
	        			System.out.println();
	        		}  
	            } 
	        }
			flag=false;
			System.out.println("Over!");
			System.exit(0);
        }
	}//end of wordsfrequency

	public void printresult(TreeMap<String, Integer> wordFrequent) throws IOException {
		Set<Map.Entry<String, Integer>> set=wordFrequent.entrySet();//����treemap�����Ŀ����
		FileWriter file = new FileWriter("result.txt");
		BufferedWriter reader = new BufferedWriter(file);

		for(Map.Entry<String, Integer> e:set)
	    {	
				reader.write(e.getKey() + ":" + e.getValue() + "\t");
	    }
  
        reader.close();
        
        System.out.println("Over!");
        System.exit(0);
	}//end of printresult

	public void topword(TreeMap<String, Integer> wordFrequent) {
		Set<Map.Entry<String, Integer>> set=wordFrequent.entrySet();	
		List<Map.Entry<String, Integer>> list = new ArrayList<Map.Entry<String, Integer>>(set);
		
		System.out.println("�����뵥�ʸ�����");
		int k = in.nextInt();
		int i;
		
		Collections.sort(list,new Comparator<Map.Entry<String,Integer>>() 
		{            
			public int compare(Map.Entry<String, Integer> o1, Map.Entry<String, Integer> o2) 
			{                
				return o2.getValue()-(o1.getValue());            
			}        
		});//end of sort
		
		for (i = 0; i < k; i++) 
		{
            System.out.println(list.get(i));
        }
		
		System.out.println("Over!");
        System.exit(0);
	}//end of topword	
}
